# APTX for Android Oreo

**This module is useless if you don't have any aptx supported headphones!**

After Oreo, system should support aptx/HD natively. But this will incur additional licensing fees, so such as Nexus5/6p will not get support for aptx/HD.

Upgrade libraries from Pie, tested them on Oreo 8.1 and works fine.

*All these libraries extracted from OxygenOS 9.0.2 from OnePlus.*

**There's no file from "Ainur Sauron" mod! Please check OxygenOS 9.0.2 by yourselves!**

**The first version was extracted from OnePlus 5T OxygenOS 5.1.5. Current version was extracted from OnePlus 6 OxygenOS 9.0.2.**

**All these files are in "vendor" partition.**

## Requirements
- Android 8+
- arm64 system

## Changelog
- v1.0 inital release
- v1.1 update pie libraries
