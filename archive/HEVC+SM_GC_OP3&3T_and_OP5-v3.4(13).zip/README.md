#### NON FUNCTIONAL AS OF NOW ON OREO ONLY HEVC WORKS ON OREO

## Changelog
v3.4 - Added device and API checks (thanks to @MarcAnt01).

v3.3 - Updated to latest Magisk Template.

v3.2 - Minor fixes to improve functionality on OxygenOS.

v3.1 - Updated to latest Magisk template.

v3.0 - Added support for Oreo (thanks to theduke7@XDA).

v2.5 - Removed 60fps mod since Modded GCam supports 60fps by default.

v2.4 - Updated to latest Magisk Template 1400.

v2.3 - Added support for OnePlus 3.

v2.2 - Fixed Slo-Mo not working in OOS Camera.

v2.1 - Enabled Slow Motion for Google Camera.

v2.0 - Added 60fps recording capability for Google Camera.

v1.1 - Added support for OnePlus 5.

v1 - Initial Release.

## Description 
This modules is specifically designed for the OnePlus 3T and 5.
It replaces the media_profiles.xml located at /system/etc/ to enable the HEVC (High Efficiency Video Codec). This results in increased quality due to the newer codec at the same bitrate which was being used with H264.
This module fixes slow motion crash on Google Camera. 
