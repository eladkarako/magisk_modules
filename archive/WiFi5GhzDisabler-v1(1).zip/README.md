# WiFi5GhzDisabler

Disable WiFi 5Ghz Band on your Qualcomm device

**NOTICE: On some ROMS with 4.x kernel and Android P (or latest) doesn't work**

Disable 5Ghz band also can solve WiFi issues in devices such Xiaomi Redmi Note 5 and Mi A2

# Credit
Based on WiFi Bounding https://github.com/Magisk-Modules-Repo/wifi-bonding

