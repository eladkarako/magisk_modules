rm -rf /data/adb/toolbox8
pm uninstall com.lazy.profiles
pm uninstall bellavita.toast

