# ChargeOverSpeed
# Magisk Module for Optimize Charging Speed: 
   Hardcore Edition=Without thermal limit;
   Green Edition   =With battery thermal limit

# 优化充电速度的面具模块：
  超硬核版=无温度限制;
  轻电池版=电池温度墙限制
