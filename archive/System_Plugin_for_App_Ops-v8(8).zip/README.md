# System Plugin for App Ops

Enable "System plugin" mode of [App Ops by Rikka](https://play.google.com/store/apps/details?id=rikka.appops).

### Usage

1. Install this module and reboot
2. Switch working mode to "System plugin" in "Setting" - "Working mode and behavior"

### Note

Due to system limit, the "System plugin" mode only works on Android 8.1 and before. You will not see "System plugin" option on Android 9+.