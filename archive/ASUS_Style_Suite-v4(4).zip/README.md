<h3 align="center">ASUS Style Suite</p>
  
<p align="center"><img src="https://image.ibb.co/f213yp/asus_logo.jpg"></p>

<h3 align="center">Hello</p>

<p align="center">
 <a href="https://forum.xda-developers.com/apps/magisk/module-asus-style-suite-magisk-t3851591"><img src="https://img.shields.io/badge/XDA-Thread-yellow.svg?longCache=true&style=flat-square"></a><br />

## There is a simple module that contain:
- Wallpapers from ASUS for their Android phones
- ASUS ROG Phone Live Wallpaper app
- ASUS ROG Phone Theme app
</p>


## This module is just a portage
- All credit @linuxct for having shared the ASUS suite tools (original XDA thread).


## Compatibility:</p>
- Magisk (last stable version at least)
- An Android phone (oh really ? )
- 5 minutes of your time
- (download, install, reboot and set the wallpaper take too much of your time? REALLY ? )
    This should works on any Android Device

### Updates
- v2 - AsusCamera app and 2 props added

## Source
* [Github](https://github.com/xerta555/ASUS-Style-Suite/releases/download/v1/ASUS-Style-Suite.zip "Source")
