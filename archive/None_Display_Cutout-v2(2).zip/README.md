# None Display Cutout

This module provide you a option for hide your devices display cutout(notch).

Support Android P(ie), Q(uince Tart) and R(ed Velvet Cake).

Android O and below will not work

Tested on OnePlus 8T.

### Usage

`Settings - Dev Options - Cutout Emulation - None Display Cutout`

### Community

QQ chat group: [855219808](http://shang.qq.com/wpa/qunwpa?idkey=fae42a3dba9dc758caf63e971be2564e67bf7edd751a2ff1c750478b0ad1ca3f)

Telegram group: [Code_Of_MeowCat](http://t.me/code_of_meowcat)