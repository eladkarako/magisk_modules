SKIPUNZIP=1

ROOT_PATH="/data/adb/sui"
mkdir $ROOT_PATH
set_perm "$ROOT_PATH" 0 0 0600

# Check architecture
if [ "$ARCH" != "arm" ] && [ "$ARCH" != "arm64" ] && [ "$ARCH" != "x86" ] && [ "$ARCH" != "x64" ]; then
  abort "! Unsupported platform: $ARCH"
else
  ui_print "- Device platform: $ARCH"
fi

# extract verify.sh
ui_print "- Extracting verify.sh"
unzip -o "$ZIPFILE" 'verify.sh' -d "$TMPDIR" >&2
if [ ! -f "$TMPDIR/verify.sh" ]; then
  ui_print "*********************************************************"
  ui_print "! Unable to extract verify.sh!"
  ui_print "! This zip may be corrupted, please try downloading again"
  abort "*********************************************************"
fi
. $TMPDIR/verify.sh

# Extract riru.sh
extract "$ZIPFILE" 'riru.sh' "$TMPDIR"
. $TMPDIR/riru.sh

check_riru_version
enforce_install_from_magisk_app

# Extract libs
ui_print "- Extracting module files"

extract "$ZIPFILE" 'module.prop' "$MODPATH"
extract "$ZIPFILE" 'post-fs-data.sh' "$MODPATH"
extract "$ZIPFILE" 'uninstall.sh' "$MODPATH"
extract "$ZIPFILE" 'sepolicy.rule' "$MODPATH"

mkdir "$MODPATH/riru"
mkdir "$MODPATH/riru/lib"
mkdir "$MODPATH/riru/lib64"
mkdir "$MODPATH/bin"
mkdir "$MODPATH/system"
mkdir "$MODPATH/system/lib"
mkdir "$MODPATH/system/lib64"

if [ "$ARCH" = "x86" ] || [ "$ARCH" = "x64" ]; then
  ui_print "- Extracting x86 libraries"
  extract "$ZIPFILE" "lib/x86/lib$RIRU_MODULE_LIB_NAME.so" "$MODPATH/riru/lib" true

  if [ "$IS64BIT" = true ]; then
    ui_print "- Extracting x64 libraries"
    extract "$ZIPFILE" "lib/x86_64/lib$RIRU_MODULE_LIB_NAME.so" "$MODPATH/riru/lib64" true
    extract "$ZIPFILE" "lib/x86_64/libmain.so" "$MODPATH/bin" true
    extract "$ZIPFILE" "lib/x86_64/libadbd_wrapper.so" "$MODPATH/bin" true
    extract "$ZIPFILE" "lib/x86_64/libadbd_preload.so" "$MODPATH/lib" true
    extract "$ZIPFILE" "lib/x86_64/librish.so" "$MODPATH" true
  else
    extract "$ZIPFILE" "lib/x86/libmain.so" "$MODPATH/bin" true
    extract "$ZIPFILE" "lib/x86/libadbd_wrapper.so" "$MODPATH/bin" true
    extract "$ZIPFILE" "lib/x86/libadbd_preload.so" "$MODPATH/lib" true
    extract "$ZIPFILE" "lib/x86/librish.so" "$MODPATH" true
  fi
fi

if [ "$ARCH" = "arm" ] || [ "$ARCH" = "arm64" ]; then
  ui_print "- Extracting arm libraries"
  extract "$ZIPFILE" "lib/armeabi-v7a/lib$RIRU_MODULE_LIB_NAME.so" "$MODPATH/riru/lib" true

  if [ "$IS64BIT" = true ]; then
    ui_print "- Extracting arm64 libraries"
    extract "$ZIPFILE" "lib/arm64-v8a/lib$RIRU_MODULE_LIB_NAME.so" "$MODPATH/riru/lib64" true
    extract "$ZIPFILE" "lib/arm64-v8a/libmain.so" "$MODPATH/bin" true
    extract "$ZIPFILE" "lib/arm64-v8a/libadbd_wrapper.so" "$MODPATH/bin" true
    extract "$ZIPFILE" "lib/arm64-v8a/libadbd_preload.so" "$MODPATH/lib" true
    extract "$ZIPFILE" "lib/arm64-v8a/librish.so" "$MODPATH" true
  else
    extract "$ZIPFILE" "lib/armeabi-v7a/libmain.so" "$MODPATH/bin" true
    extract "$ZIPFILE" "lib/armeabi-v7a/libadbd_wrapper.so" "$MODPATH/bin" true
    extract "$ZIPFILE" "lib/armeabi-v7a/libadbd_preload.so" "$MODPATH/lib" true
    extract "$ZIPFILE" "lib/armeabi-v7a/librish.so" "$MODPATH" true
  fi
fi

mv "$MODPATH/bin/libmain.so" "$MODPATH/bin/sui"
mv "$MODPATH/bin/libadbd_wrapper.so" "$MODPATH/bin/adbd_wrapper"

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/bin/sui" 0 0 0700

# Extract server files
ui_print "- Extracting Sui files"

extract "$ZIPFILE" 'sui.dex' "$MODPATH"
extract "$ZIPFILE" 'sui.apk' "$MODPATH"

set_perm "$MODPATH/sui.dex" 0 0 0600
set_perm "$MODPATH/sui.apk" 0 0 0655
set_perm_recursive "$MODPATH/res" 0 0 0700 0600

ui_print "- Fetching information for SystemUI and Settings"
/system/bin/app_process -Djava.class.path="$MODPATH"/sui.dex /system/bin --nice-name=sui_installer rikka.sui.installer.Installer "$MODPATH"

ui_print "- Extracting files for rish"
extract "$ZIPFILE" 'rish' "$MODPATH"
extract "$ZIPFILE" 'post-install.example.sh' "$MODPATH"
set_perm "$MODPATH/rish" 0 2000 0770
set_perm "$MODPATH/post-install.example.sh" 0 0 0600

if [ -f $ROOT_PATH/post-install.sh ]; then
  cat "$ROOT_PATH/post-install.sh" | grep -q "SCRIPT_VERSION=2"
  if [ "$?" -eq 0 ]; then
    RISH_DEX=$MODPATH/sui.dex
    RISH_LIB=$MODPATH/librish.so
    RISH_SCRIPT=$MODPATH/rish
    ui_print "- Run /data/adb/sui/post-install.sh"
    source $ROOT_PATH/post-install.sh
  else
    ui_print "! To use new interactive shell tool (rish), post-install.sh needs update"
    ui_print "! Please check post-install.example.sh for more"
  fi
else
  ui_print "- Cannot find /data/adb/sui/post-install.sh"
fi

# Remove unused files
ui_print "- Removing old files"
rm -rf /data/adb/sui/res
rm -rf /data/adb/sui/res.new
rm -f /data/adb/sui/com.android.settings
rm -f /data/adb/sui/com.android.systemui
rm -f /data/adb/sui/post-install.example.sh
rm -f /data/adb/sui/starter
rm -f /data/adb/sui/sui.dex
rm -f /data/adb/sui/sui.dex.new
rm -f /data/adb/sui/sui_wrapper
