#!/sbin/sh
rm -rf "/data/adb/sui"
