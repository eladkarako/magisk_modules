# Changelog

### v6.2.0

- Update to the latest implementation by OP.

### v6.1.0

- Bring back OnePlus OG Cached App Limit properties.

### v6.0

- Updated to the latest magisk codes.

### v5.0

- Adapt Nord Properties.

### v4.0

- Updated to latest Magisk Template & Merged Latest limit implementation.

### v3.0

- Updated to treble vendor compliance.

### v2.0

- Cached app limits was raised to 50 by default.

### v1.0

- Initial Release.
