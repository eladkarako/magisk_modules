#!/system/bin/sh

setprop ro.opa.eligible_device true
setprop ro.product.model Pixel

# This script will be executed in post-fs mode
# More info in the main Magisk thread