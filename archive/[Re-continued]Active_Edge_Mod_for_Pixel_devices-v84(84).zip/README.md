Re-continued by mikalovtch. Thanks to @jtothe4n for his hard work.
Special thanks to @i5lee8bit for his tool to update module automatically every month.