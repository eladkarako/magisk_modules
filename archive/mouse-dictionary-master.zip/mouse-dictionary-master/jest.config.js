module.exports = {
  testEnvironment: "jsdom",
  moduleNameMapper: {
    "^ponyfill$": "<rootDir>/src/main/lib/ponyfill/chrome",
  },
};
