/**
 * Mouse Dictionary (https://github.com/wtetsu/mouse-dictionary/)
 * Copyright 2018-present wtetsu
 * Licensed under MIT
 */

const env = {
  enableWindowStatusSave: true,
  enableUserSettings: true,
};

export default env;
