/**
 * Mouse Dictionary (https://github.com/wtetsu/mouse-dictionary/)
 * Copyright 2018-present wtetsu
 * Licensed under MIT
 */
export * from "./simpledictparser";
export * from "./jsondictparser";
export * from "./eijiroparser";
