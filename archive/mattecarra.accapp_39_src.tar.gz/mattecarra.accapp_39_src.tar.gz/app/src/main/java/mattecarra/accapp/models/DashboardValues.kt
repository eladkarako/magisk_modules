package mattecarra.accapp.models

data class DashboardValues(
    var batteryInfo: BatteryInfo,
    var daemon: Boolean?
) {
}