# Google Assistant Enabler
This magisk module enables Google Assistant on phones running Nougat.
