# Disable both screenshot and camera sounds

Most ROMs offer the option to disable camera click, but not the screenshot sound. This module does it, by replacing systemlessly the sound files with an empty version.
