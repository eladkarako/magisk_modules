AUTOMOUNT=true

PROPFILE=true

POSTFSDATA=false

LATESTARTSERVICE=false

  rm -r /data/vendor/radio && rm -r /data/vendor/modem_fdr

set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
}
