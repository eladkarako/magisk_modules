![IMG_20210105_222157_267](https://user-images.githubusercontent.com/67799176/103706233-6f91f780-4fa4-11eb-877c-5d47a1c27cdb.jpg)

# ZeetaaTweaks

#### Notes:
```
- Support all Devices
- This is a Magisk Module created
by @NotZeetaa ( U need to Flash in Magisk )
- This Module improves your
Performance and Battery
- Check new Updates and Support Group
 Below!
```
<p align="center">
  <a href="https://sourceforge.net/projects/m-dulos/files/ZeetaaTweaks/"><img src="https://img.shields.io/badge/Download-Module-red.svg"></a> <br/><a href="https://t.me/ZeetaaProjects"><img src="https://img.shields.io/badge/Telegram-Channel-red.svg"></a><br/><a href="https://t.me/ZeetaaProjectsGroup"><img src="https://img.shields.io/badge/Telegram-Group-red.svg"></a> <br/><a href="https://t.me/ZeetaaProjectsGroupBr"><img src="https://img.shields.io/badge/Telegram-GroupBr-red.svg"></a>
</p>
<br/> 

#### Credits:
- @akira-vishal for help alot and Bish Gang 😂
- @jack08 for that Lob Banner and Support all The time 😍
- Thx to All Beta Testers 🥰😘

## Changelog 

### ZeetaaTweaks Module App V2:
App:
- Updated all Scripts
- Added Main Log ( By @Paget96  )
- Improved image of logs
- Improved Scheduler ( In all Profiles )
- Removed alot of things
- Fixed Pwr level in Battery profile and Balanced Profile
- Fixed Perf in Performance and Gaming Profile
- Alot of things

Module:
-  Reduced a bit of Apply on Boot
- Added Optimized Univerl Thermal
- Removed System Prop
- Added A11 Support and Reworked a bit in Ui

### ZeetaaTweaks V13:
- Set the Dev stune boost to Gaming mode to 20
- Set the Default Power Level to 1  ( Gaming Profile )
- Removed Power suspend in Gaming and Battery Profile
- Set the input boost duration to 1000 in battery profile and dynamic to 0
- Improved Dynamic Stune to Gaming Profile 
- Added Gpu Tweaks And switched to echo in Gaming and Battery Profile
- Removed Gms Blockers and Alarm Blockers in Gaming And Battery profile
- Removed Fsync In Battery Profile
- Removed Kcal Config in Battery Profile 
- Removed zRam Tweaks in Battery Profile
- Removed Rt tweaks in Battery Profile
- Removed Tcp Type in Battey Profile
- Removed Log in Performance Profile
- Added Gms Blockers Config
- Added Compiler Config ( Source things )
- Fixed Missed Letters ( In Gms Blocker )
- Removed Simple Time for Now
- Removed Above_hispeed_load
- Enabled Boost Parameter
- Removed hispeed_load for now
- Removed go_hispeed_load parameter for now
- Removed Kernel Tweaks for now
- Reworked in blu_schedutil tweaks
- autoperf: Added Epic Package Name Support

### ZeetaaTweaks V12
- Set the Dev stune boost to Gaming mode to 20
- Set the Default Power Level to 1  ( Gaming Profile )
- Removed Power suspend in Gaming and Battery Profile
- Set the input boost duration to 1000 in battery profile and dynamic to 0
- Improved Dynamic Stune to Gaming Profile 
- Added Gpu Tweaks And switched to echo in Gaming and Battery Profile
- Removed Gms Blockers and Alarm Blockers in Gaming And Battery profile
- Removed Fsync In Battery Profile
- Removed Kcal Config in Battery Profile 
- Removed zRam Tweaks in Battery Profile
- Removed Rt tweaks in Battery Profile
- Removed Tcp Type in Battey Profile
- Removed Log in Performance Profile
- Added Gms Blockers Config

### ZeetaaTweaks V11:
- Added Support For ALL DEVICES
- Removed some Kernel Settings ( Maybe Conflit with ram and Other Things)
- Added More Force stop apps
- Reduced the time while flashing
- Added 1 More Perf Prop
- Reworked in Schedutil Configs ( Better Bb )
- Reworked in Blu-Scheditil Configs ( Better BB )
- Reworked in Interactive Configs ( Better BB )
- Added Selinux To Permissive
- Reworked in Caf Cpu Boost ( For Better Perf )
- Reworked in Interactive Configs ( Better Perf )
- fixed bad Deep sleep
- Added More System Props Tweaks
- Added Gpu Prop
- Added disable Logs Prop
- Added Analytics Remover ( Better BB )
- Added Vol+ and Vol- Config
- Added Lavender Perf Thermal
- Added Masik Pulse Audio ( All Credits to Masik Team )
- Removed Lib and Lib64 from Lavender Thermals
- Added More Props
- Removed Power Efficient

### ZeetaaTweaks vX:
- Fixed Bootloop ( In some Devices)
- Fixed Random Reboots ( In some Devices )
- Fixed the Brightness too low
- Added PowerHint
- Added Gpu Force Clk On
- Added Gpu Idler Timer
- Added Gpu Force Rail On
- Reworked in some values in Dev Stune Boost ( Less heat , More bb)
- Added Better Idling
- Disabled PowerEfficient
- Added Better DeepSleep
- Added 1 more Perf Prop
- Added Battery Prop
- Added Other Props
- Removed BlackLight Drimmer
- Disabled PerfDump
- Added More values to Caf Cpu Boost ( Better Perf)
- Removed Adreno Idler
- Reworked in Values of Fs ( Better Perf )
- Added Renice apps at Wake
- Killed Some Media Process
- Added Cleanner ( To clean Junk Files )
- Added Touch Switch Improve
- Added Kernel Settings
- Forced Close some apps
- Added Trimmer Data/Cache/System
- Added more Services to Gms Blocker
- Added Google.xml ( Optimized For Bb )
- Removed Kcal Config

### ZeetaaTweaks V9:
- Added hw3d and hw2d force prop
- Added Fast dormancy
- Added Battery Prop
- Added Performance Prop
- Reworked in Some Values in Entropy ( Better bb )
- Added Default Cubic TCP
- Added More Gms Blocker
- Reworked in Ls-Breake-Time ( Better Perf )
- Reworked in Dev stune ( Better Perf )
- Added Mixer Paths ( Audio Improve )
- Added Audio Prop From Poco X2
- Added Sched Rt Tweaks
- Reduced the Saturation 
- Improved the RGB
- Changed Some Values for Improve Performance
- Disabled Adreno Idler
- Added Video accelerate

### ZeetaaTweaks V8:
- Removed Spectrum Support
- Removed Doze Settings 
- Added Kcal Config
- Added 90 Fps in Pubg ( If u have only Extreme , Repair the Game client )
- Added Gpu No Throttling
- Added Gpu PowerLevel
- Added Backlight Drimmer
- Added More Gms Blocker
- Added Fs Confings thx to @AkiraSuper
- Added Alarm Blocker 
- Added Adreno Idler
- Added Interactive Configs 
- Added Schedutil Configs
- Added Blu_Schedutil Configs
- Added Cpu Input boost
- Added Scheduler
- Added Dev Stune boost
- Added PowerSuspend
- Added some Persists Configs
- Disabled Fsync
- Better Sensivity in games
- Reworked in some values of Caf Cpu Boost

### ZeetaaTweaks V7:
- Added More Perf Tweaks
- Added Perf Tweaks ( Smart Profile )
- Added Battery Twekas ( Smart Profile )
-Rebased on v5 ( With alot of Improvemets below )
- Removed Something ( Maybe caused some performance drops )
- Fixed The Battery Saver ( U Now can turn on and off )
- Improved Some Values in Gaming , Performance Profile
- Reduced Some Values in Balanced Profile
- Removed some Tweaks
- Removed audio Tweaks
- Added Support for System.prop
- Removed The Freq per profiles

### ZeetaaTweaks V6:
- Reworked on dev stune values
- Reworked on interactive settings ( for Better Battery in Battery Profile )
- Added Gms Blocker
- Added DT2W Fix
- Added TouchPaint Configs
- Reworked on go_hispeed_load in Battery , Balanced , Performance , Gaming profiles for no Drain/Heat

### ZeetaaTweaks V5:
- Added Optimizations thx to @kedorian
- Added Doze Settings
- Added Caf Cpu Boost
- Added WakeLock Blocker
- Disabled FindMyDevice ( Miui Users )
- Added Perf Tweak and Battery Tweak
- Removed some Useless Things
- Reworked some values in Battery Tweak
- Added PowerEfficient ( Better Power Saver  but not affect Performance )
- Fixed WhatsApp lag in Eas Kernel
- Added alot dev stune , Schedetune Boost for Better efficient
- Fixed Instagram Lag

### ZeetaaTweaks V4:
- Fixed App Crash
- Fixed WhatsApp lag
- Fixed Youtube Live not working
- Removed PowerHint
- Removed some Tweaks cause conflints
- Fixed High Battery Drain ( For me its Better alot )
- Fixed Camera issues

### ZeetaaTweaks V3:
- Fixed Location in Balanced/Performance/Gaming Profile
- Fixed Battery Saver in Battery/Balanced Profile
- Reworked Battery/Balanced/Performance profile for Better heat and Bb
- Reworked Schedtune Boost and DevStuneBoost in Battery/Balanced/Performance/Gaming Profile
- Reworked Battery Profile some paremeters to saver more power
- Added PowerHint Thx to @i_m_akira and @Smiley_18
- Fixed Video Lag in WhatsApp
- Reworked in Some tweaks
- Removed some Configs in Battery/Balanced/Performance/Gaming Profile

### ZeetaaTweaks V2:
- Added Spectrum Support
- Added More Battery Tweaks ( To make balanced )
- Fixed The audio
- Rebase Perf Tweks ( Less Heat/Drain )
- Added TouchPaint Thx to @i_m_akira

### ZeetaaTweaks V1:
- Initial Release 
- Added Audio Improvements 
- Added Fast Ui Tweaks
- Added Performance Tweaks
- Added Gaming Tweaks
- Added Battery Tweaks
- Added Good Ram Management
- Added Dalvilk Improvements
