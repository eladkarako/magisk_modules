# TWRP A/B Retention Script
### osm0sis @ xda-developers
*Keep TWRP installed after an A/B OTA*

### Links
* [GitHub](https://github.com/Magisk-Modules-Repo/TWRP-A-B-Retention-Script)
* [Support](https://forum.xda-developers.com/showthread.php?t=2239421)
* [Sponsor](https://github.com/sponsors/osm0sis)
* [Donate](https://www.paypal.me/osm0sis)

### Description
**This is NOT a normal module - it will NOT show up in the Magisk app's installed modules list.**

Flash this script zip after each OTA has installed, but before you install Magisk to Inactive Slot from the Magisk app

Initial install should be from the Downloads section in the Magisk app, then subsequent flashes can be from the Modules section using the + button and selecting the downloaded zip from internal storage
