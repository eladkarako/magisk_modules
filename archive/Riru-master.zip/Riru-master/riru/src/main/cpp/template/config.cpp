#include "config.h"

namespace riru {
    const int versionCode = ${RIRU_VERSION_CODE};
    const char* const versionName = "${RIRU_VERSION_NAME}";
    const int apiVersion = ${RIRU_API_VERSION};
    const int minApiVersion = ${RIRU_MIN_API_VERSION};
}
