### v1.5
- Fix incorrect detection in case there are multiple zygote proccesses
